import sys
sys.path.append('..')

import pandas as pd
import matplotlib.pyplot as plt

from src.data_input import DataInput
from src.calculations import LCACalculator
from src.visualization import LCAVisualizer